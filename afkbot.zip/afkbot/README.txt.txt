HOW TO USE THIS BOT ON GLITCH.COM (24/7)

1. Go to https://glitch.com and sign up.
2. Click "New Project" → "Hello Node".
3. Delete all default files.
4. Drag and drop bot.js and package.json into the project.
5. Wait for Glitch to install packages.
6. Click "Run" — bot will join your server.
7. Keep the project open in your account; Glitch will keep it online.

TIP: Put the bot in a safe area so it doesn't die in-game.
